#!/usr/bin/env python3
#coding: utf-8

from base64 import b85decode

def main(DATA):
    with open("ENTER_FILENAME_HERE", "wb") as fp:
        fp.write(b85decode(DATA.replace(b"\n", b"")))

DATA = b"""
ENTER_ENCODED_DATA_HERE
"""

if __name__ == "__main__":
    main(DATA)
